﻿namespace Example_CollectFullCalibrationData
{
    public enum Standard { Short, Open, Load, Through };
}
